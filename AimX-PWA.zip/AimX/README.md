# AimX — Sensitivity Studio

This is a lightweight installable web app (PWA) starter project.

## Included
- Vivo Y16 profile plus other device categories
- Playstyle and finger-count based starting sensitivity suggestions
- Copy, save, load and delete profiles (stored locally in the browser)
- PWA manifest and service worker for install/offline support

## Run locally
Open `index.html` in a browser to test the generator. PWA installation and offline caching require hosting over HTTPS (for example, GitHub Pages).

## Publish with GitHub Pages
1. Create a GitHub repository named `AimX`.
2. Upload all files in this folder to the repository root (not inside another nested folder).
3. In the repository, open Settings → Pages.
4. Choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site. Open the Pages URL in Chrome on Android.
6. Use Chrome's menu → Install app / Add to Home screen (the exact wording can vary).

## Notes
- Sensitivity numbers are illustrative starting points, not official Garena recommendations.
- Tune them gradually in the game's training area. Device performance, game updates, HUD layout and personal control all matter.
- AimX does not modify Free Fire and contains no macros, scripts or game hooks.
- The current PWA is the web/Android-installable version. A native APK would require a separate Android packaging/build step.
