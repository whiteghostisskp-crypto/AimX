const $=id=>document.getElementById(id);
const labels=["General","Red Dot","2x Scope","4x Scope","Sniper Scope","Free Look"];
const base={
  vivo:[92,86,80,72,48,65],
  entry:[88,82,76,68,45,62],
  mid:[94,88,82,74,50,68],
  high:[98,92,86,78,54,72],
  iphone:[96,90,84,76,52,70],
  tablet:[90,84,78,70,48,66]
};
const styleShift={balanced:[0,0,0,0,0,0],rush:[7,6,4,2,0,2],precision:[-7,-5,-5,-6,-3,-2],drag:[5,4,3,1,0,0]};
let current=[];
function generate(){
  const device=$("device").value, style=$("style").value, fingers=Number($("fingers").value);
  const shift=styleShift[style];
  const fingerBonus=fingers>=4?2:fingers===3?1:0;
  current=base[device].map((v,i)=>Math.max(0,Math.min(200,v+shift[i]+(i<4?fingerBonus:0))));
  $("values").innerHTML=labels.map((name,i)=>`<div class="value"><small>${name}</small><strong>${current[i]}</strong></div>`).join("");
  $("status").textContent="New starting settings generated.";
}
function readSaved(){try{return JSON.parse(localStorage.getItem("aimxProfiles")||"[]")}catch(e){return []}}
function writeSaved(list){localStorage.setItem("aimxProfiles",JSON.stringify(list))}
function renderSaved(){
 const list=readSaved(); const box=$("saved");
 if(!list.length){box.innerHTML='<p class="hint">No saved profiles yet. Generate settings and tap “Save profile”.</p>';return}
 box.innerHTML=list.map((p,i)=>`<div class="saved-item"><div><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.deviceName)} • ${escapeHtml(p.styleName)} • ${p.values.join(" / ")}</small></div><div><button data-load="${i}">Load</button> <button data-delete="${i}">Delete</button></div></div>`).join("");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
$("generate").addEventListener("click",generate);
$("copy").addEventListener("click",async()=>{
 if(!current.length)generate();
 const txt=labels.map((l,i)=>`${l}: ${current[i]}`).join("\n");
 try{await navigator.clipboard.writeText(txt);$("status").textContent="Settings copied."}catch(e){$("status").textContent=txt}
});
$("save").addEventListener("click",()=>{
 if(!current.length)generate();
 const list=readSaved(); const deviceName=$("device").selectedOptions[0].text;
 const styleName=$("style").selectedOptions[0].text;
 list.unshift({name:`${deviceName} • ${styleName}`,deviceName,styleName,device:$("device").value,style:$("style").value,fingers:$("fingers").value,values:current});
 writeSaved(list.slice(0,20));renderSaved();$("status").textContent="Profile saved on this device.";
});
$("saved").addEventListener("click",e=>{
 const load=e.target.dataset.load, del=e.target.dataset.delete, list=readSaved();
 if(load!==undefined){const p=list[Number(load)];$("device").value=p.device;$("style").value=p.style;$("fingers").value=p.fingers;current=p.values;$("values").innerHTML=labels.map((n,i)=>`<div class="value"><small>${n}</small><strong>${current[i]}</strong></div>`).join("");$("status").textContent="Saved profile loaded."}
 if(del!==undefined){list.splice(Number(del),1);writeSaved(list);renderSaved()}
});
generate();renderSaved();
let installPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("installBtn").hidden=false});
$("installBtn").addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("installBtn").hidden=true});
if("serviceWorker" in navigator && location.protocol.startsWith("http")) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
